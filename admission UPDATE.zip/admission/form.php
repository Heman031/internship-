<?php
session_start();

/* -------------------------------
   SERVER-SIDE VALIDATION
-------------------------------- */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    /* AGE VALIDATION */
    $dob = $_POST['dob'];
    $dobDate = new DateTime($dob);
    $today   = new DateTime();
    $age     = $today->diff($dobDate)->y;

    if ($age < 17) {
        echo "<script>
            alert('Applicant must be at least 17 years old to apply.');
            window.history.back();
        </script>";
        exit;
    }

    /* PASSWORD VALIDATION */
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    if ($password !== $confirm) {
        echo "<script>
            alert('Passwords do not match.');
            window.history.back();
        </script>";
        exit;
    }

    if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$/', $password)) {
        echo "<script>
            alert('Password must be at least 8 characters and include uppercase, lowercase, number, and special character.');
            window.history.back();
        </script>";
        exit;
    }

    /* HASH PASSWORD */
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $_SESSION['form_data'] = [
        'programme'   => $_POST['programme'],
        'name'        => $_POST['name'],
        'mobile'      => $_POST['mobile'],
        'email'       => $_POST['email'],
        'password'    => $hashedPassword, // 🔐 login ready
        'dob'         => $_POST['dob'],
        'course_id'   => $_POST['course'],
        'course_name' => $_POST['course_name'],
        'eligibility' => $_POST['eligibility']
    ];

    header("Location: next.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Distance Education Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="top-header">
    <div class="container1">
        <div class="logo">
            <img src="image/Univ.png">
            <div class="logo-text">
                <div class="tamil-text">
                    சென்னை பல்கலைக்கழகம் – தொலைதூரக் கல்வி நிறுவனம்
                </div>
                <div class="english-text">
                    University of Madras – Institute of Distance Education
                </div>
            </div>
        </div>
        <nav class="nav">
            <a class="active" href="#">Home</a>
            <a href="#">About Us</a>
            <a href="#">Contact Us</a>
        </nav>
    </div>
</header>

<div class="container">
<h2>Distance Education Application Form</h2>

<form method="post">
<div class="sub">

<label>Programme</label>
<select name="programme" onchange="loadCourses(this.value)" required>
    <option value="">-- Select Programme --</option>
    <option value="UG">Under Graduate</option>
    <option value="PG">Post Graduate</option>
    <option value="Diploma">Diploma</option>
    <option value="Certificate">Certificate</option>
</select>

<label>Name</label>
<input type="text" name="name" required>

<label>Mobile</label>
<input type="text" name="mobile" maxlength="10" pattern="[0-9]{10}" required>

<label>Email</label>
<input type="email" name="email" required>

<!-- 🔐 PASSWORD FIELDS -->
<label>Password</label>
<input type="password" name="password" id="password" required oninput="validatePassword()">

<label>Confirm Password</label>
<input type="password" name="confirm_password" id="confirm_password" required oninput="validatePassword()">

<small id="passwordHint" style="color:red;"></small>

<label>Date of Birth</label>
<input
    type="date"
    name="dob"
    required
    oninput="validateAge()"
    max="<?php echo date('Y-m-d', strtotime('-17 years')); ?>"
>

<label>Course</label>
<select name="course" id="course" onchange="loadEligibility(this)" required>
    <option value="">-- Select Course --</option>
</select>

</div>

<div id="eligibilityBox" class="note">
    Eligibility will appear here
</div>

<input type="hidden" name="eligibility" id="eligibility">
<input type="hidden" name="course_name" id="course_name">

<label>
    <input type="checkbox" required> All details are authorized
</label>

<button type="submit" id="nextBtn" disabled>Next</button>
</form>
</div>

<script src="script.js"></script>

<script>
/* AGE VALIDATION */
function validateAge() {
    const dobInput = document.querySelector('input[name="dob"]');
    const nextBtn  = document.getElementById("nextBtn");

    if (!dobInput.value) {
        nextBtn.disabled = true;
        return;
    }

    const dob = new Date(dobInput.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;

    nextBtn.disabled = age < 17;
}

/* PASSWORD VALIDATION */
function validatePassword() {
    const pwd  = document.getElementById("password").value;
    const cpwd = document.getElementById("confirm_password").value;
    const hint = document.getElementById("passwordHint");
    const nextBtn = document.getElementById("nextBtn");

    const regex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

    if (!regex.test(pwd)) {
        hint.innerText = "Password must be 8+ chars with uppercase, lowercase, number & special character.";
        nextBtn.disabled = true;
        return;
    }

    if (pwd !== cpwd) {
        hint.innerText = "Passwords do not match.";
        nextBtn.disabled = true;
        return;
    }

    hint.innerText = "";
    nextBtn.disabled = false;
}

window.onload = function () {
    loadCourses('UG');
};
</script>

<footer>
    <p>© 2026 University of Madras. All Rights Reserved.</p>
</footer>

</body>
</html>
