<?php
session_start();
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

/* Prevent direct access */
if (!isset($_SESSION['form_data'])) {
    header("Location: form.php");
    exit;
}

$email  = $_SESSION['form_data']['email'];
$otp    = (string) rand(100000, 999999);
$expiry = date("Y-m-d H:i:s", strtotime("+5 minutes"));

/* Check if user already exists */
$check = $conn->prepare("SELECT is_verified FROM users WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$result = $check->get_result();

if ($row = $result->fetch_assoc()) {

    if ($row['is_verified'] == 1) {
        echo "<script>
            alert('Email already verified.');
            window.location='form.php';
        </script>";
        exit;
    }

    /* Update OTP + expiry */
    $update = $conn->prepare(
        "UPDATE users 
         SET otp=?, otp_expires_at=?, is_verified=0 
         WHERE email=?"
    );
    $update->bind_param("sss", $otp, $expiry, $email);
    $update->execute();

} else {

    /* Insert new user */
    $insert = $conn->prepare(
        "INSERT INTO users (email, otp, otp_expires_at, is_verified)
         VALUES (?, ?, ?, 0)"
    );
    $insert->bind_param("sss", $email, $otp, $expiry);
    $insert->execute();
}

/* Store email for verification page */
$_SESSION['otp_email'] = $email;

/* SEND OTP EMAIL */
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'hemaoffice153@gmail.com';
    $mail->Password   = 'pqub jypz oxfn dzkg'; // app password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('hemaoffice153@gmail.com', 'Distance Education');
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = "OTP Verification";
    $mail->Body    = "
        <h2>Your OTP</h2>
        <p><strong>$otp</strong></p>
        <p>This OTP is valid for 5 minutes.</p>
    ";

    $mail->send();
    header("Location: verify_otp.php");
    exit;

} catch (Exception $e) {
    echo "Mail Error: {$mail->ErrorInfo}";
}
