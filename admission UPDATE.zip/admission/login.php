<?php
session_start();
include "db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare(
        "SELECT id, password 
         FROM users 
         WHERE email=? AND is_verified=1"
    );
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {

        if (password_verify($password, $row['password'])) {

            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_email'] = $email;

            header("Location: form.php");
            exit;

        } else {
            $error = "Invalid email or password";
        }

    } else {
        $error = "Account not found or not verified";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Login | Distance Education</title>
<link rel="stylesheet" href="style.css">

<style>
/* RESET */
* {
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

/* BANNER — FIXED */
.banner {
    min-height: calc(100vh - 140px);
    background: url("image/back.jpeg") no-repeat center center/cover;
    display: flex;
    align-items: center;
    justify-content: center;   /* ✅ CENTER */
}

/* LOGIN BOX */
.login-box {
    background: rgba(255,255,255,0.96);
    width: 380px;
    padding: 35px;
    border-radius: 6px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.25);
}

/* TITLE */
.login-box h2 {
    margin-bottom: 20px;
    color: #0c1d42;
    font-size: 24px;
}

/* INPUTS */
.login-box input {
    width: 100%;
    padding: 12px;
    margin: 12px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 15px;
}

.login-box input:focus {
    border-color: #0c1d42;
    outline: none;
}

/* BUTTON */
.login-box button {
    background: #0c1d42;
    color: white;
    padding: 12px;
    width: 100%;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
}

.login-box button:hover {
    background: #142d6b;
}

/* ERROR */
.error {
    background: #ffe5e5;
    color: #c62828;
    padding: 8px;
    border-radius: 4px;
    font-size: 14px;
    margin-bottom: 10px;
}

/* LINKS */
.login-links {
    margin-top: 15px;
    font-size: 14px;
    text-align: center;
}

.login-links a {
    color: #1a73e8;
    text-decoration: none;
}

.login-links a:hover {
    text-decoration: underline;
}

/* SHOW PASSWORD */
.show-pass {
    display: flex;
    align-items: center;
    font-size: 14px;
}

.show-pass input {
    width: auto;
    margin-right: 5px;
}

/* MOBILE */
@media (max-width: 768px) {
    .login-box {
        width: 90%;
    }
}
</style>
</head>

<body>

<header class="top-header">
    <div class="container1">
        <div class="logo">
            <img src="image/Univ.png">
            <div class="logo-text">
                <div class="tamil-text">
                    சென்னை பல்கலைக்கழகம் – தொலைதூரக் கல்வி நிறுவனம்
                </div>
                <div class="english-text">
                    University of Madras – Institute of Distance Education
                </div>
            </div>
        </div>
        <nav class="nav">
            <a href="form.php">Home</a>
            <a class="active" href="#">Login</a>
        </nav>
    </div>
</header>

<div class="banner">
    <div class="login-box">

        <h2>Student Login</h2>

        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post">
            <input type="email" name="email" placeholder="Registered Email" required>
            <input type="password" name="password" id="password" placeholder="Password" required>

            <div class="show-pass">
                <input type="checkbox" onclick="togglePassword()"> Show Password
            </div>

            <button type="submit">Login</button>
        </form>

        <div class="login-links">
            <p><a href="forgot_password.php">Forgot Password?</a></p>
            <p>New Applicant? <a href="form.php">Apply Now</a></p>
        </div>

    </div>
</div>

<footer>
    <p>© 2026 University of Madras. All Rights Reserved.</p>
</footer>

<script>
function togglePassword() {
    const pwd = document.getElementById("password");
    pwd.type = pwd.type === "password" ? "text" : "password";
}
</script>

</body>
</html>
