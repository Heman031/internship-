<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Page</title>

<style>
body{
    font-family: 'Segoe UI', sans-serif;
    background:#eef2f7;
    margin:0;
}

/* HEADER */
.top-header{
    background:linear-gradient(135deg,#1e3c72,#2a5298);
    color:#fff;
    padding:15px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.left-header{
    display:flex;
    align-items:center;
    gap:12px;
}

.logo img{
    width:55px;
    height:55px;
    background:#fff;
    border-radius:50%;
    padding:5px;
}

.title{
    font-size:18px;
    font-weight:600;
}

.sub{
    font-size:12px;
    opacity:0.9;
}

/* MAIN CONTAINER */
.container{
    max-width:900px;
    margin:30px auto;
    padding:20px;
}

/* NEW SEARCH DESIGN */
.search-wrapper{
    display:flex;
    justify-content:center;
    margin-top:30px;
}

.search-card{
    background:#f5f7fa;
    padding:25px;
    border-radius:15px;
    width:500px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.search-label{
    font-size:18px;
    font-weight:600;
    color:#2c3e50;
    display:block;
    margin-bottom:15px;
}

.search-box-pro{
    display:flex;
    gap:10px;
}

.search-box-pro input{
    flex:1;
    padding:12px;
    border-radius:10px;
    border:1px solid #ccc;
    font-size:14px;
}

.search-box-pro input:focus{
    outline:none;
    border-color:#2a5298;
}

.search-box-pro button{
    background:linear-gradient(135deg,#2a5298,#1e3c72);
    color:#fff;
    border:none;
    padding:12px 20px;
    border-radius:10px;
    font-weight:600;
    cursor:pointer;
}

.search-box-pro button:hover{
    opacity:0.9;
}

/* CARD */
.card{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    margin-top:20px;
}

/* DETAILS GRID */
.details{
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap:15px;
}

.details div{
    background:#f7f9fc;
    padding:10px;
    border-radius:6px;
}

/* BUTTONS */
.btn{
    padding:12px 20px;
    border:none;
    border-radius:8px;
    font-weight:600;
    cursor:pointer;
}

.pay-btn{
    background:#27ae60;
    color:#fff;
}

.pay-btn:hover{
    background:#219150;
}

.mark-btn{
    background:#e74c3c;
    color:#fff;
}

.mark-btn:hover{
    background:#c0392b;
}

/* FOOTER */
.footer{
    background:#1e3c72;
    color:#fff;
    text-align:center;
    padding:15px;
    margin-top:300px;
}

/* PRINT */
@media print{
    .top-header,.footer{display:none;}
}
</style>

</head>
<body>

<!-- HEADER -->
<div class="top-header">
    <div class="left-header">
        <div class="logo">
            <img src="image/Univ.png">
        </div>
        <div>
            <div class="title">UNIVERSITY OF MADRAS</div>
            <div class="sub">Institute of Distance Education</div>
        </div>
    </div>
    <div>🎓 Payment Portal</div>
</div>

<h2 style="text-align:center;">Payment Page</h2>

<!-- SEARCH -->
<div class="search-wrapper">

    <form method="GET" class="search-card">

        <label class="search-label">
            🔍 Enrollment Number
        </label>

        <div class="search-box-pro">
            <input 
                type="text" 
                name="enrollment_no" 
                placeholder="Enter Enrollment No (Eg: A26101UEC6017)" 
                required
            >

            <button type="submit">Search</button>
        </div>

    </form>

</div>



<?php
if(isset($_GET['enrollment_no'])){

    $en = trim($_GET['enrollment_no']);

    $stmt = $pdo->prepare("SELECT * FROM records WHERE enrollment_no = ?");
    $stmt->execute([$en]);
    $d = $stmt->fetch();

    if($d){

        // ===== FEE LOGIC =====
        if($d['course_type']=="UG"){ $courseTable="ug_courses"; }
        elseif($d['course_type']=="PG"){ $courseTable="pg_courses"; }
        elseif($d['course_type']=="DIP"){ $courseTable="diploma_courses"; }
        else{ $courseTable="certificate_courses"; }

        $getCourse = $pdo->prepare("SELECT course_code FROM $courseTable WHERE programme_degree=? AND main_subject=? LIMIT 1");
        $getCourse->execute([$d['programme_name'], $d['main_subject']]);
        $courseCode = $getCourse->fetch()['course_code'] ?? '';

        $feeStmt = $pdo->prepare("SELECT special_fee, tuition_fee, general_fee FROM course_fees WHERE course_code=? LIMIT 1");
        $feeStmt->execute([$courseCode]);
        $fee = $feeStmt->fetch();

        $G  = $fee['general_fee'] ?? 0;
        $SF = $fee['special_fee'] ?? 0;
        $TF = $fee['tuition_fee'] ?? 0;

        $category = strtoupper($d['approved_category'] ?? 'GENERAL');

        switch($category){
            case "VC":
            case "PRISONER": $total_fee = $G - $TF; break;
            case "DA": $total_fee = $G - ($SF + $TF); break;
            case "STAFF": $total_fee = $G - (($TF * 50)/100); break;
            default: $total_fee = $G;
        }

        if($total_fee < 0){ $total_fee = 0; }
?>

<div class="card">
<h3 style="margin-bottom:15px;">Student Details</h3>

<div class="details">

    <div><b>Name:</b> <?php echo $d['name']; ?></div>

    <div><b>Enrollment:</b> <?php echo $d['enrollment_no']; ?></div>

    <div><b>Programme:</b> 
        <?php echo $d['programme_name']; ?> - <?php echo $d['main_subject']; ?>
    </div>

    <div><b>Fees:</b> ₹<?php echo number_format($total_fee); ?></div>

    <div><b>Phone:</b> <?php echo $d['mobile']; ?></div>

    <div><b>Email:</b> <?php echo $d['email']; ?></div>

</div>

<?php if($d['paid_amount'] > 0){ ?>
    <p style="margin-top:15px;color:green;font-weight:bold;">
        Paid: ₹<?php echo $d['paid_amount']; ?>
        <br>
        <small><?php echo $d['payment_date']; ?></small>
    </p>
<?php } ?>

</div>


<!-- PAYMENT -->
<form target="_blank" method="post" action="https://apps.indianbank.in/muexam/finalCustModule.aspx">

<input name="UserId" type="hidden" value="IdeUnom">
<input name="PassWord" type="hidden" value="MuniCh1857">
<input name="RegNo" type="hidden" value="<?php echo $d['enrollment_no']; ?>">
<input name="Name" type="hidden" value="<?php echo $d['name']; ?>">
<input name="Purpose" type="hidden" value="APPLICATION_FEE">
<input name="Degree" type="hidden" value="JUNE25MCAEXAMFEE">
<input name="Amt" type="hidden" value="<?php echo $total_fee; ?>">

<div style="text-align:center;">
<input style="padding:10px 20px;background:#27ae60;color:#fff;border:none;border-radius:6px;" 
type="submit" value="💳 Pay Now">
</div>

</form>

<br>

<!-- MARK PAID -->
<div style="text-align:center;">
<form method="POST">
<input type="hidden" name="paid_enrollment" value="<?php echo $d['enrollment_no']; ?>">
<input type="hidden" name="paid_amount" value="<?php echo $total_fee; ?>">
<button style="padding:10px;background:#e74c3c;color:#fff;border:none;border-radius:6px;" 
type="submit" name="mark_paid">
Mark as Paid
</button>
</form>
</div>

<?php
    } else {
        echo "<h3 style='color:red;text-align:center;'>No record found!</h3>";
    }
}
?>

<?php
// MARK PAID WITH AMOUNT
if(isset($_POST['mark_paid'])){

    $enroll = $_POST['paid_enrollment'];
    $amount = $_POST['paid_amount'];

    $stmt = $pdo->prepare("
        UPDATE records 
        SET fees = 0, paid_amount = ?, payment_date = NOW() 
        WHERE enrollment_no = ?
    ");
    $stmt->execute([$amount, $enroll]);

    echo "<script>alert('Payment Stored Successfully');window.location.reload();</script>";
}
?>

<!-- FOOTER -->
<div class="footer">
© <?php echo date("Y"); ?> University of Madras | Payment System
</div>

</body>
</html>